#!/usr/bin/env bash
# Installs vsftpd for the shared account (jailed in its home), passive mode and optional FTPS.
source "$(dirname "$0")/lib/common.sh"

log "Installing vsftpd"
pkg_install vsftpd openssl

if [[ $DISTRO_FAMILY == debian ]]; then
  CONF=/etc/vsftpd.conf
  USERLIST=/etc/vsftpd.userlist
  PAM_SVC=vsftpd
else
  CONF=/etc/vsftpd/vsftpd.conf
  USERLIST=/etc/vsftpd/user_list.lab
  PAM_SVC=vsftpd
fi
backup_file "$CONF"

# ---------- Shared account (created by 00-user.sh) ----------
id "$LAB_USER" >/dev/null 2>&1 || bash "$(dirname "$0")/00-user.sh"

echo "$LAB_USER" > "$USERLIST"

# ---------- TLS (reuse the web certificate, create it if missing) ----------
CRT=${TLS_DIR}/server.crt
KEY=${TLS_DIR}/server.key
if [[ $FTP_ENABLE_TLS == yes && ( ! -s $CRT || ! -s $KEY ) ]]; then
  mkdir -p "$TLS_DIR"
  openssl req -x509 -nodes -newkey rsa:2048 -days "$TLS_DAYS" \
    -keyout "$KEY" -out "$CRT" -subj "/CN=${WEB_SERVER_NAME}"
  chmod 600 "$KEY"
fi

if [[ $FTP_ENABLE_TLS == yes ]]; then
  [[ $FTP_FORCE_TLS == yes ]] && FORCE=YES || FORCE=NO
  TLS_BLOCK="ssl_enable=YES
rsa_cert_file=${CRT}
rsa_private_key_file=${KEY}
ssl_tlsv1=YES
ssl_sslv2=NO
ssl_sslv3=NO
require_ssl_reuse=NO
ssl_ciphers=HIGH
force_local_logins_ssl=${FORCE}
force_local_data_ssl=${FORCE}"
else
  TLS_BLOCK="ssl_enable=NO"
fi

# Optional public IP for passive mode behind NAT: export FTP_PASV_ADDRESS=x.x.x.x before running
PASV_ADDR_LINE=""
[[ -n ${FTP_PASV_ADDRESS:-} ]] && PASV_ADDR_LINE="pasv_address=${FTP_PASV_ADDRESS}"

cat > "$CONF" <<EOF
# Managed by linux-services-setup/03-ftp.sh
listen=YES
listen_ipv6=NO
anonymous_enable=NO
local_enable=YES
write_enable=YES
local_umask=022
dirmessage_enable=YES
use_localtime=YES
xferlog_enable=YES
xferlog_std_format=YES
connect_from_port_20=YES
ftpd_banner=Welcome to ${WEB_SERVER_NAME} FTP service.

# Jail users in their home directory
chroot_local_user=YES
allow_writeable_chroot=YES

# Only users listed in ${USERLIST} may log in
userlist_enable=YES
userlist_file=${USERLIST}
userlist_deny=NO

# Passive mode
pasv_enable=YES
pasv_min_port=${FTP_PASV_MIN}
pasv_max_port=${FTP_PASV_MAX}
${PASV_ADDR_LINE}

pam_service_name=${PAM_SVC}
secure_chroot_dir=/var/run/vsftpd/empty

${TLS_BLOCK}
EOF
mkdir -p /var/run/vsftpd/empty

if selinux_enforcing; then
  setsebool -P ftpd_full_access on
fi

systemctl enable vsftpd
systemctl restart vsftpd
ok "FTP server active on port 21 (passive ${FTP_PASV_MIN}-${FTP_PASV_MAX})"
ok "FTP login: ${LAB_USER} (same password as SSH)"
