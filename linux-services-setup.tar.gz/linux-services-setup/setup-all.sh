#!/usr/bin/env bash
# Runs every setup step in order and logs everything to /var/log/lab-setup.log
#   sudo ./setup-all.sh            -> all steps
#   sudo ./setup-all.sh ssh web    -> only selected steps (user | ssh | web | ftp | firewall | check)
set -euo pipefail
cd "$(dirname "$0")"
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo $0"; exit 1; }

LOG=/var/log/lab-setup.log
exec > >(tee -a "$LOG") 2>&1
echo "===== $(date -u) – lab setup start ====="

declare -A STEPS=([user]=00-user.sh [ssh]=01-ssh.sh [web]=02-web.sh [ftp]=03-ftp.sh [firewall]=04-firewall.sh [check]=99-check.sh)
ORDER=(user ssh web ftp firewall check)
SELECTED=("$@"); [[ ${#SELECTED[@]} -eq 0 ]] && SELECTED=("${ORDER[@]}")

chmod +x ./*.sh lib/*.sh; chmod 600 config.env
for s in "${ORDER[@]}"; do
  [[ " ${SELECTED[*]} " == *" $s "* ]] || continue
  echo; echo "---------- [$s] ${STEPS[$s]} ----------"
  bash "./${STEPS[$s]}"
done

echo; echo "===== done – full log in ${LOG} ====="
