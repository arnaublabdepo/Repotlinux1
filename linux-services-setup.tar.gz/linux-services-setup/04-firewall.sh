#!/usr/bin/env bash
# Opens the service ports with ufw (Debian/Ubuntu) or firewalld (RHEL family).
source "$(dirname "$0")/lib/common.sh"

[[ $CONFIGURE_FIREWALL == yes ]] || { log "Firewall step disabled in config.env"; exit 0; }

TCP_PORTS=("$SSH_PORT" "$HTTP_PORT" "$HTTPS_PORT" 21 20)
PASV_RANGE="${FTP_PASV_MIN}-${FTP_PASV_MAX}"

if command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld; then
  log "Configuring firewalld"
  for p in "${TCP_PORTS[@]}"; do firewall-cmd --permanent --add-port="${p}/tcp" >/dev/null; done
  firewall-cmd --permanent --add-port="${PASV_RANGE}/tcp" >/dev/null
  firewall-cmd --reload
  ok "firewalld: $(firewall-cmd --list-ports)"

elif [[ $DISTRO_FAMILY == debian ]]; then
  command -v ufw >/dev/null 2>&1 || pkg_install ufw
  log "Configuring ufw (SSH is allowed BEFORE enabling, so the current session stays open)"
  ufw allow "${SSH_PORT}/tcp" comment 'SSH'
  ufw allow "${HTTP_PORT}/tcp" comment 'HTTP'
  ufw allow "${HTTPS_PORT}/tcp" comment 'HTTPS'
  ufw allow 20:21/tcp comment 'FTP'
  ufw allow "${FTP_PASV_MIN}:${FTP_PASV_MAX}/tcp" comment 'FTP passive'
  ufw --force enable
  ufw status verbose

else
  warn "No active firewalld found – ports not opened. Start firewalld or open them manually:"
  warn "  tcp ${TCP_PORTS[*]} and ${PASV_RANGE}"
fi

warn "Cloud VM? Also open these ports in your security group / NSG."
