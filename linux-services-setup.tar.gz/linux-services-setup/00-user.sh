#!/usr/bin/env bash
# Creates the single account shared by SSH, SCP/SFTP and FTP.
source "$(dirname "$0")/lib/common.sh"

[[ -n $LAB_USER && -n $LAB_PASSWORD ]] || die "LAB_USER and LAB_PASSWORD must be set in config.env"

if id "$LAB_USER" >/dev/null 2>&1; then
  log "User ${LAB_USER} already exists – updating it"
  usermod -s /bin/bash "$LAB_USER"
else
  useradd -m -s /bin/bash "$LAB_USER"
  log "User ${LAB_USER} created"
fi
echo "${LAB_USER}:${LAB_PASSWORD}" | chpasswd
ok "Password set for ${LAB_USER}"

if [[ $LAB_USER_SUDO == yes ]]; then
  [[ $DISTRO_FAMILY == debian ]] && ADMIN_GROUP=sudo || ADMIN_GROUP=wheel
  pkg_install sudo
  usermod -aG "$ADMIN_GROUP" "$LAB_USER"
  SUDO_FILE=/etc/sudoers.d/90-${LAB_USER}
  if [[ $LAB_SUDO_NOPASSWD == yes ]]; then
    echo "${LAB_USER} ALL=(ALL:ALL) NOPASSWD: ALL" > "$SUDO_FILE"
  else
    echo "${LAB_USER} ALL=(ALL:ALL) ALL" > "$SUDO_FILE"
  fi
  chmod 440 "$SUDO_FILE"
  visudo -cf "$SUDO_FILE" >/dev/null || { rm -f "$SUDO_FILE"; die "Invalid sudoers file"; }
  ok "${LAB_USER} is super admin (group ${ADMIN_GROUP} + ${SUDO_FILE})"
fi

HOME_DIR=$(getent passwd "$LAB_USER" | cut -d: -f6)
mkdir -p "${HOME_DIR}/${UPLOAD_DIR_NAME}"
chown "${LAB_USER}:${LAB_USER}" "${HOME_DIR}/${UPLOAD_DIR_NAME}"
ok "Upload folder ready: ${HOME_DIR}/${UPLOAD_DIR_NAME}"
