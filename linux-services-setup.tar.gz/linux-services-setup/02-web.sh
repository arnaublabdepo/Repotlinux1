#!/usr/bin/env bash
# Installs nginx, generates a self-signed TLS certificate, serves a site on HTTP and HTTPS.
source "$(dirname "$0")/lib/common.sh"

log "Installing nginx + openssl"
pkg_install nginx openssl

# ---------- TLS certificate (self-signed, with SAN) ----------
mkdir -p "$TLS_DIR"; chmod 755 "$TLS_DIR"
CRT=${TLS_DIR}/server.crt
KEY=${TLS_DIR}/server.key
if [[ ! -s $CRT || ! -s $KEY ]]; then
  IPS=$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^[0-9.]+$' | sed 's/^/IP:/' | paste -sd, -)
  SAN="DNS:${WEB_SERVER_NAME},DNS:localhost,IP:127.0.0.1${IPS:+,$IPS}"
  log "Generating self-signed certificate (SAN: ${SAN})"
  openssl req -x509 -nodes -newkey rsa:2048 -days "$TLS_DAYS" \
    -keyout "$KEY" -out "$CRT" \
    -subj "/CN=${WEB_SERVER_NAME}" -addext "subjectAltName=${SAN}"
  chmod 600 "$KEY"; chmod 644 "$CRT"
else
  log "Certificate already present in ${TLS_DIR} – kept"
fi

# ---------- Web content ----------
mkdir -p "$WEB_ROOT"
cat > "${WEB_ROOT}/index.html" <<EOF
<!doctype html>
<html><head><meta charset="utf-8"><title>${WEB_SERVER_NAME}</title></head>
<body style="font-family:sans-serif;margin:3rem">
  <h1>It works – ${WEB_SERVER_NAME}</h1>
  <p>Served by nginx. Deployed on $(date -u '+%Y-%m-%d %H:%M UTC').</p>
</body></html>
EOF
echo ok > "${WEB_ROOT}/health"

# ---------- nginx site ----------
if [[ $DISTRO_FAMILY == debian ]]; then
  rm -f /etc/nginx/sites-enabled/default
  WEB_USER=www-data
else
  # RHEL's nginx.conf ships its own default server on port 80: drop its default_server flag
  backup_file /etc/nginx/nginx.conf
  sed -i 's/\s*default_server//g' /etc/nginx/nginx.conf
  WEB_USER=nginx
fi
chown -R "${WEB_USER}:${WEB_USER}" "$WEB_ROOT"

if [[ $REDIRECT_HTTP_TO_HTTPS == yes ]]; then
  HTTP_BODY="    location / { return 301 https://\$host:${HTTPS_PORT}\$request_uri; }"
else
  HTTP_BODY="    root ${WEB_ROOT};
    index index.html;
    location / { try_files \$uri \$uri/ =404; }"
fi

# Listen on IPv6 only if the kernel supports it (avoids "Address family not supported")
if [[ -s /proc/net/if_inet6 ]]; then
  V6_HTTP="    listen [::]:${HTTP_PORT} default_server;"
  V6_HTTPS="    listen [::]:${HTTPS_PORT} ssl default_server;"
else
  V6_HTTP="    # IPv6 disabled on this host"; V6_HTTPS="$V6_HTTP"
fi

cat > /etc/nginx/conf.d/lab.conf <<EOF
# Managed by linux-services-setup/02-web.sh
server {
    listen ${HTTP_PORT} default_server;
${V6_HTTP}
    server_name ${WEB_SERVER_NAME} _;
${HTTP_BODY}
}

server {
    listen ${HTTPS_PORT} ssl default_server;
${V6_HTTPS}
    server_name ${WEB_SERVER_NAME} _;

    ssl_certificate     ${CRT};
    ssl_certificate_key ${KEY};
    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;
    ssl_session_cache   shared:LAB:10m;

    add_header Strict-Transport-Security "max-age=31536000" always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;

    root ${WEB_ROOT};
    index index.html;
    location / { try_files \$uri \$uri/ =404; }
}
EOF

# ---------- SELinux ----------
if selinux_enforcing; then
  pkg_install policycoreutils-python-utils
  semanage fcontext -a -t httpd_sys_content_t "${WEB_ROOT}(/.*)?" 2>/dev/null || true
  restorecon -R "$WEB_ROOT"
  for p in "$HTTP_PORT" "$HTTPS_PORT"; do
    [[ $p == 80 || $p == 443 ]] && continue
    semanage port -a -t http_port_t -p tcp "$p" 2>/dev/null || semanage port -m -t http_port_t -p tcp "$p"
  done
fi

nginx -t || die "nginx configuration test failed"
systemctl enable nginx
systemctl restart nginx
ok "nginx active – http://${WEB_SERVER_NAME}:${HTTP_PORT}  https://${WEB_SERVER_NAME}:${HTTPS_PORT}"
