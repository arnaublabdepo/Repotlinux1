#!/usr/bin/env bash
# Installs and configures the OpenSSH server.
source "$(dirname "$0")/lib/common.sh"

log "Installing OpenSSH server (${DISTRO_FAMILY})"
if [[ $DISTRO_FAMILY == debian ]]; then
  pkg_install openssh-server
  SSH_SVC=ssh
else
  pkg_install openssh-server policycoreutils-python-utils
  SSH_SVC=sshd
fi

MAIN_CONF=/etc/ssh/sshd_config
DROPIN_DIR=/etc/ssh/sshd_config.d
# sshd keeps the FIRST value it reads, so "00-" makes ours win over e.g. 50-cloud-init.conf
DROPIN=${DROPIN_DIR}/00-lab.conf
backup_file "$MAIN_CONF"

# Use a drop-in file when sshd_config includes the .d directory (Ubuntu 20.04+, Debian 11+, RHEL 9+)
if grep -qE '^\s*Include\s+/etc/ssh/sshd_config.d/' "$MAIN_CONF"; then
  mkdir -p "$DROPIN_DIR"
  TARGET=$DROPIN
else
  TARGET=$MAIN_CONF
  sed -i '/^# BEGIN LAB SETTINGS/,/^# END LAB SETTINGS/d' "$MAIN_CONF"
fi

SETTINGS="# BEGIN LAB SETTINGS
Port ${SSH_PORT}
PermitRootLogin ${SSH_PERMIT_ROOT_LOGIN}
PasswordAuthentication ${SSH_PASSWORD_AUTH}
PubkeyAuthentication yes
KbdInteractiveAuthentication no
X11Forwarding no
MaxAuthTries 4
LoginGraceTime 30
ClientAliveInterval 300
ClientAliveCountMax 2
# END LAB SETTINGS"

if [[ $TARGET == "$DROPIN" ]]; then
  printf '%s\n' "$SETTINGS" > "$TARGET"
else
  # In the main file first match wins too: prepend our block
  { printf '%s\n' "$SETTINGS"; cat "$MAIN_CONF"; } > "${MAIN_CONF}.new" && mv "${MAIN_CONF}.new" "$MAIN_CONF"
fi
log "SSH settings written to ${TARGET}"

# SELinux: allow a non-standard SSH port
if [[ $SSH_PORT != 22 ]] && selinux_enforcing; then
  semanage port -a -t ssh_port_t -p tcp "$SSH_PORT" 2>/dev/null \
    || semanage port -m -t ssh_port_t -p tcp "$SSH_PORT"
fi

# Ubuntu 22.10+ uses socket activation: the port is set on ssh.socket, so prefer the service
if systemctl list-unit-files ssh.socket >/dev/null 2>&1 && systemctl is-enabled ssh.socket >/dev/null 2>&1; then
  systemctl disable --now ssh.socket || true
fi

mkdir -p /run/sshd

# SCP and SFTP: modern scp (OpenSSH 9+) transfers files over the SFTP subsystem, so it must exist
if ! sshd -T 2>/dev/null | grep -qi '^subsystem sftp'; then
  printf 'Subsystem sftp internal-sftp\n' >> "$TARGET"
  log "SFTP subsystem enabled (needed by scp)"
fi
command -v scp >/dev/null 2>&1 || pkg_install openssh-clients 2>/dev/null || pkg_install openssh-client

sshd -t || die "sshd configuration test failed – check ${TARGET}"
systemctl enable "$SSH_SVC"
systemctl restart "$SSH_SVC"
ok "SSH server active on port ${SSH_PORT} (service: ${SSH_SVC}) – SCP and SFTP enabled"
ok "Upload example: scp -P ${SSH_PORT} myfile.txt ${LAB_USER}@<server-ip>:~/${UPLOAD_DIR_NAME}/"
