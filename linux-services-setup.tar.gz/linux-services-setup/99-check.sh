#!/usr/bin/env bash
# Verifies that every service is running, listening and answering.
source "$(dirname "$0")/lib/common.sh"
set +e

FAIL=0
check() { if eval "$2" >/dev/null 2>&1; then ok "$1"; else warn "$1 -> FAILED"; FAIL=1; fi; }

[[ $DISTRO_FAMILY == debian ]] && SSH_SVC=ssh || SSH_SVC=sshd
command -v curl >/dev/null 2>&1 || pkg_install curl >/dev/null

echo "== Services =="
check "service ${SSH_SVC} active" "systemctl is-active --quiet ${SSH_SVC}"
check "service nginx active"      "systemctl is-active --quiet nginx"
check "service vsftpd active"     "systemctl is-active --quiet vsftpd"

echo "== Listening ports =="
for p in "$SSH_PORT" "$HTTP_PORT" "$HTTPS_PORT" 21; do
  check "tcp/${p} listening" "ss -Htln 'sport = :${p}' | grep -q ."
done

echo "== Account =="
check "${LAB_USER} exists"         "id ${LAB_USER}"
check "${LAB_USER} has full sudo"  "sudo -l -U ${LAB_USER} | grep -q '(ALL'"

echo "== Functional tests =="
check "SSH banner"          "timeout 5 bash -c 'head -c 4 </dev/tcp/127.0.0.1/${SSH_PORT}' | grep -q SSH"
check "HTTP  /health"       "curl -fsS  http://127.0.0.1:${HTTP_PORT}/health -L -k"
check "HTTPS /health"       "curl -fsSk https://127.0.0.1:${HTTPS_PORT}/health"
check "FTP banner"          "timeout 5 bash -c 'head -c 3 </dev/tcp/127.0.0.1/21' | grep -q 220"

command -v sshpass >/dev/null 2>&1 || pkg_install sshpass >/dev/null
SSH_OPTS="-P ${SSH_PORT} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o LogLevel=ERROR"
TESTFILE=$(mktemp); echo "scp test $(date)" > "$TESTFILE"
check "SCP upload as ${LAB_USER}" "SSHPASS='${LAB_PASSWORD}' sshpass -e scp ${SSH_OPTS} '${TESTFILE}' '${LAB_USER}@127.0.0.1:${UPLOAD_DIR_NAME}/scp-test.txt'"
HOME_DIR=$(getent passwd "$LAB_USER" | cut -d: -f6)
check "SCP file landed in ~/${UPLOAD_DIR_NAME}" "cmp -s '${TESTFILE}' '${HOME_DIR}/${UPLOAD_DIR_NAME}/scp-test.txt'"
rm -f "$TESTFILE" "${HOME_DIR}/${UPLOAD_DIR_NAME}/scp-test.txt"

SSL_OPT=""; [[ $FTP_ENABLE_TLS == yes ]] && SSL_OPT="--ssl-reqd -k"
check "FTP login + listing as ${LAB_USER}" "curl -fsS ${SSL_OPT} --list-only ftp://127.0.0.1/ --user '${LAB_USER}:${LAB_PASSWORD}'"

echo
ss -tlnp | grep -E ":(${SSH_PORT}|${HTTP_PORT}|${HTTPS_PORT}|21)\b" || true
echo
[[ $FAIL -eq 0 ]] && ok "All checks passed" || die "Some checks failed – see journalctl -u <service>"
