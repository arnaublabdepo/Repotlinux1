#!/usr/bin/env bash
# Shared helpers: logging, root check, distro detection, package install.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=../config.env
source "${SCRIPT_DIR}/config.env"

log()  { printf '\e[1;34m[INFO]\e[0m  %s\n' "$*"; }
ok()   { printf '\e[1;32m[ OK ]\e[0m  %s\n' "$*"; }
warn() { printf '\e[1;33m[WARN]\e[0m  %s\n' "$*" >&2; }
die()  { printf '\e[1;31m[FAIL]\e[0m  %s\n' "$*" >&2; exit 1; }

require_root() {
  [[ $EUID -eq 0 ]] || die "Run as root (sudo $0)"
}

detect_distro() {
  [[ -r /etc/os-release ]] || die "Cannot read /etc/os-release"
  # shellcheck disable=SC1091
  . /etc/os-release
  case " ${ID} ${ID_LIKE:-} " in
    *" debian "*|*" ubuntu "*) DISTRO_FAMILY=debian ;;
    *" rhel "*|*" fedora "*|*" centos "*|*" rocky "*|*" almalinux "*) DISTRO_FAMILY=rhel ;;
    *) die "Unsupported distribution: ${PRETTY_NAME:-$ID}" ;;
  esac
  export DISTRO_FAMILY
}

pkg_update_done=0
pkg_install() {
  if [[ $DISTRO_FAMILY == debian ]]; then
    if [[ $pkg_update_done -eq 0 ]]; then
      DEBIAN_FRONTEND=noninteractive apt-get update -y
      pkg_update_done=1
    fi
    DEBIAN_FRONTEND=noninteractive apt-get install -y "$@"
  else
    dnf install -y "$@"
  fi
}

backup_file() {
  local f=$1
  [[ -f $f && ! -f ${f}.orig ]] && cp -a "$f" "${f}.orig" && log "Backup: ${f}.orig"
  return 0
}

selinux_enforcing() {
  command -v getenforce >/dev/null 2>&1 && [[ $(getenforce) == Enforcing ]]
}

require_root
detect_distro
